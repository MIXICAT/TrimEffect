package com.mix.trimeffect;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimPattern;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class TrimEffectPlugin extends JavaPlugin {
    private final Map<String, PatternRule> rules = new HashMap<>();
    private BukkitTask task;
    private int amplifier;
    private int durationTicks;
    private int refreshIntervalTicks;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();

        task = Bukkit.getScheduler().runTaskTimer(this, this::applyTrimEffects, 1L, refreshIntervalTicks);
        getLogger().info("TrimEffect enabled with " + rules.size() + " trim rules.");
    }

    @Override
    public void onDisable() {
        if (task != null) task.cancel();
        // Remove effects managed by this plugin when it is disabled.
        for (Player player : Bukkit.getOnlinePlayers()) {
            for (PatternRule rule : rules.values()) {
                player.removePotionEffect(rule.effect());
            }
        }
    }

    private void loadSettings() {
        rules.clear();
        amplifier = Math.max(0, getConfig().getInt("amplifier", 0));
        durationTicks = Math.max(20, getConfig().getInt("duration-ticks", 100));
        refreshIntervalTicks = Math.max(10, getConfig().getInt("refresh-interval-ticks", 40));

        ConfigurationSection section = getConfig().getConfigurationSection("patterns");
        if (section == null) return;

        for (String patternName : section.getKeys(false)) {
            ConfigurationSection patternSection = section.getConfigurationSection(patternName);
            if (patternSection == null || !patternSection.getBoolean("enabled", true)) continue;

            String effectName = patternSection.getString("effect", "");
            PotionEffectType effect = resolveEffect(effectName);
            if (effect == null) {
                getLogger().warning("Unknown potion effect '" + effectName + "' for pattern '" + patternName + "'. Skipping.");
                continue;
            }

            int pieces = Math.max(1, Math.min(4, patternSection.getInt("pieces", 4)));
            rules.put(patternName.toLowerCase(Locale.ROOT), new PatternRule(effect, pieces));
        }
    }

    private PotionEffectType resolveEffect(String name) {
        if (name == null || name.isBlank()) return null;
        String normalized = name.toUpperCase(Locale.ROOT);
        // Legacy Bukkit enum aliases retained for potion effect names.
        if (normalized.equals("DAMAGE_RESISTANCE")) normalized = "RESISTANCE";
        if (normalized.equals("INCREASE_DAMAGE")) normalized = "STRENGTH";
        if (normalized.equals("FAST_DIGGING")) normalized = "HASTE";
        return Registry.EFFECT.get(NamespacedKey.minecraft(normalized.toLowerCase(Locale.ROOT)));
    }

    private void applyTrimEffects() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Map<String, Integer> counts = new HashMap<>();
            for (ItemStack armorPiece : player.getInventory().getArmorContents()) {
                if (armorPiece == null || armorPiece.getType().isAir() || !armorPiece.hasItemMeta()) continue;
                if (!(armorPiece.getItemMeta() instanceof ArmorMeta meta)) continue;
                ArmorTrim trim = meta.getTrim();
                if (trim == null) continue;

                TrimPattern pattern = trim.getPattern();
                String key = patternKey(pattern);
                if (key != null) counts.merge(key, 1, Integer::sum);
            }

            for (Map.Entry<String, PatternRule> entry : rules.entrySet()) {
                String patternName = entry.getKey();
                PatternRule rule = entry.getValue();
                if (counts.getOrDefault(patternName, 0) >= rule.requiredPieces()) {
                    player.addPotionEffect(new PotionEffect(rule.effect(), durationTicks, amplifier, true, false, true));
                } else {
                    // Only clear an effect if this plugin's trim rule is no longer active.
                    player.removePotionEffect(rule.effect());
                }
            }
        }
    }

    private String patternKey(TrimPattern pattern) {
        NamespacedKey key = Registry.TRIM_PATTERN.getKey(pattern);
        if (key == null) return null;
        return key.getKey().toLowerCase(Locale.ROOT);
    }

    private record PatternRule(PotionEffectType effect, int requiredPieces) {}
}
